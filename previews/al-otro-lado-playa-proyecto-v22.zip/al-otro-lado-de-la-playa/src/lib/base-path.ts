/* ------------------------------------------------------------------ */
/*  Subcarpeta del sitio (si se publica en usuario.github.io/repo/,     */
/*  en vez de un dominio propio o usuario.github.io a secas). Mismo     */
/*  valor que `basePath` en next.config.ts, para las pocas navegaciones */
/*  que se escriben a mano (no con <Link>/<Image>, que ya lo añaden     */
/*  solos). Se fija en el build con NEXT_PUBLIC_BASE_PATH.              */
/* ------------------------------------------------------------------ */

export const BASE_PATH = process.env.NEXT_PUBLIC_BASE_PATH || "";

/**
 * Fotos de producto/combo: las de fábrica vienen como ruta relativa al
 * dominio (`/images/products/...`) y necesitan la subcarpeta a mano
 * (con `unoptimized: true`, next/image no la añade solo). Las que el
 * negocio sube desde el panel ya son URLs completas de GitHub —esas se
 * dejan tal cual—.
 */
export function withImg(src: string | undefined | null): string | undefined {
  if (!src) return undefined;
  if (/^(https?:)?\/\//.test(src)) return src;
  return `${BASE_PATH}${src}`;
}
