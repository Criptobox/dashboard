"use client";

import { useEffect } from "react";
import { BASE_PATH } from "@/lib/base-path";

/** Registra el service worker (PWA instalable, caché de respaldo) */
export function PwaRegister() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;
    const onLoad = () => {
      navigator.serviceWorker.register(`${BASE_PATH}/sw.js`).catch(() => {
        /* sin SW no pasa nada grave */
      });
    };
    if (document.readyState === "complete") onLoad();
    else window.addEventListener("load", onLoad);
    return () => window.removeEventListener("load", onLoad);
  }, []);
  return null;
}
