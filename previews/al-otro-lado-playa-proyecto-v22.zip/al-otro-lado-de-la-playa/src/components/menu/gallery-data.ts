import type { GalleryItem } from "@/lib/types";
import { BASE_PATH } from "@/lib/base-path";

/**
 * Galería por defecto de «Así se vive el shack».
 * Se usa mientras el negocio no haya subido sus propias fotos
 * (settings.gallery) desde el panel de administración.
 */
export const DEFAULT_GALLERY: GalleryItem[] = [
  {
    src: `${BASE_PATH}/images/shack/s-carrito.jpg`,
    caption: "El carrito al atardecer",
    alt: "Carrito del shack en la arena al atardecer",
  },
  {
    src: `${BASE_PATH}/images/shack/s-barra.jpg`,
    caption: "La barra y sus jugos",
    alt: "Barra de madera del shack con frutas y luces",
  },
  {
    src: `${BASE_PATH}/images/shack/s-punto.jpg`,
    caption: "Calle 21 e/ 14 · Vedado",
    alt: "Esquina del Vedado al anochecer con el puesto iluminado",
  },
  {
    src: `${BASE_PATH}/images/shack/s-atardecer.jpg`,
    caption: "Nuestra playa, la del otro lado",
    alt: "Atardecer en la playa con palmeras y tabla de surf",
  },
];
